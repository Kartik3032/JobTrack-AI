function Features() {
    const features = [
        {
            title: "AI Resume Review",
            desc: "Get instant AI suggestions to improve your resume."
        },
        {
            title: "Application Tracker",
            desc: "Track every job application in one dashboard."
        },
        {
            title: "Interview Preparation",
            desc: "Practice coding, aptitude and HR questions."
        }
    ];

    return (
        <section className="bg-black text-white py-24 px-8">

            <h2 className="text-5xl font-bold text-center mb-16">
                Why Choose JobTrack AI?
            </h2>

            <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">

                {features.map((item, index) => (
                    <div
                        key={index}
                        className="bg-zinc-900 rounded-2xl p-8 hover:scale-105 duration-300 border border-zinc-800"
                    >
                        <h3 className="text-2xl font-bold mb-4">
                            {item.title}
                        </h3>

                        <p className="text-gray-400">
                            {item.desc}
                        </p>
                    </div>
                ))}

            </div>

        </section>
    );
}

export default Features;