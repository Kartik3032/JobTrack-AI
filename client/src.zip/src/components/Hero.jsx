function Hero() {
    return (
        <section className="min-h-[85vh] flex flex-col justify-center items-center text-center px-6">
            <h1 className="text-6xl md:text-7xl font-extrabold text-white leading-tight">
                Land Your Dream Job
            </h1>

            <span className="text-6xl md:text-7xl font-extrabold text-purple-500">
                Faster with AI 🚀
            </span>

            <p className="text-gray-400 mt-6 text-lg max-w-2xl">
                JobTrack AI helps students discover jobs, track applications,
                prepare for interviews, and stay organized—all in one place.
            </p>

            <div className="mt-10 flex gap-5">
                <button className="bg-purple-600 hover:bg-purple-700 transition px-8 py-3 rounded-lg text-white font-semibold">
                    Get Started
                </button>

                <button className="border border-gray-500 hover:border-purple-500 transition px-8 py-3 rounded-lg text-white">
                    Learn More
                </button>
            </div>
        </section>
    );
}

export default Hero;